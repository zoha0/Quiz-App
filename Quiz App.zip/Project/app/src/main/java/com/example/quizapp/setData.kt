package com.example.quizapp

object setData {

    const val name:String="name"
    const val score:String="score"

   fun getQuestion():ArrayList<QuestionData>{
       var que:ArrayList<QuestionData> = arrayListOf()

       var question1 = QuestionData(
           1,
           "largest country in the world is  ?",

           "United States",
           "Canada",
           "China",
           "Russia",
           4
       )
       var question2 = QuestionData(
           2,
           "City of gardens in pakistan ?",

           "Lahore",
           "Peshawar",
           "Faisalabad",
           "None of the above",
           1
       )
       var question3 = QuestionData(
           3,
           "City of mosques in turkey?",

           "Antalya",
           "Istanbul",
           "Ankara",
           "İzmir",
           2
       )
       var question4 = QuestionData(
           4,
           "The world largest mountain is  ?",

           "Nanga Parbat",
           "Makalu",
           "Mount Everest",
           "Cho Oyu",
           3
       )

       var question5 = QuestionData(
           5,
           "Total population of the world ?",

           "9.1 billion",
           " 6.3billion",
           "8.2billion",
           "7.9 billion",
           4
       )

       que.add(question1)
       que.add(question2)
       que.add(question3)
       que.add(question4)
       que.add(question5)
       return que
   }
}